# MRGcodexNET

**MRGcodexNET** is an advanced, encrypted Netcat-style cybersecurity networking toolkit
for labs, education, and authorized testing.

## Features
- Encrypted client/server (AES-256-GCM)
- Secure file transfer
- TCP port scanner
- Traffic relay / pivot
- Cross-platform Go binary

## Build
```bash
go build ./cmd
```

## Legal
For educational and authorized use only.
