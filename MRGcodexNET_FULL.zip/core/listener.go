package core

import (
	"bufio"
	"fmt"
	"net"
	"os"

	"mrgcodexnet/crypto"
)

func Listen(port, password string) {
	key := crypto.KeyFromPassword(password)
	ln, _ := net.Listen("tcp", ":"+port)
	fmt.Println("[+] Listening on", port)
	conn, _ := ln.Accept()
	fmt.Println("[+] Client connected")

	go stdinToConn(conn, key)
	connToStdout(conn, key)
}

func Connect(target, password string) {
	key := crypto.KeyFromPassword(password)
	conn, _ := net.Dial("tcp", target)
	fmt.Println("[+] Connected to", target)

	go stdinToConn(conn, key)
	connToStdout(conn, key)
}

func stdinToConn(conn net.Conn, key []byte) {
	sc := bufio.NewScanner(os.Stdin)
	for sc.Scan() {
		enc, _ := crypto.Encrypt(sc.Bytes(), key)
		conn.Write(enc)
	}
}

func connToStdout(conn net.Conn, key []byte) {
	buf := make([]byte, 8192)
	for {
		n, err := conn.Read(buf)
		if err != nil { return }
		dec, err := crypto.Decrypt(buf[:n], key)
		if err == nil {
			fmt.Println(string(dec))
		}
	}
}
