package main

import (
	"fmt"
	"os"

	"mrgcodexnet/core"
	"mrgcodexnet/modules"
)

func usage() {
	fmt.Println("MRGcodexNET")
	fmt.Println("Usage:")
	fmt.Println("  listen <port> <password>")
	fmt.Println("  connect <ip:port> <password>")
	fmt.Println("  scan <ip> <start-end>")
	fmt.Println("  transfer send <file> <ip:port> <password>")
	fmt.Println("  relay <localPort> <remoteIP:remotePort>")
}

func main() {
	if len(os.Args) < 2 {
		usage()
		return
	}
	switch os.Args[1] {
	case "listen":
		if len(os.Args) != 4 { usage(); return }
		core.Listen(os.Args[2], os.Args[3])
	case "connect":
		if len(os.Args) != 4 { usage(); return }
		core.Connect(os.Args[2], os.Args[3])
	case "scan":
		if len(os.Args) != 4 { usage(); return }
		modules.Scan(os.Args[2], os.Args[3])
	case "transfer":
		if len(os.Args) != 6 || os.Args[2] != "send" { usage(); return }
		modules.SendFile(os.Args[3], os.Args[4], os.Args[5])
	case "relay":
		if len(os.Args) != 4 { usage(); return }
		modules.Relay(os.Args[2], os.Args[3])
	default:
		usage()
	}
}
