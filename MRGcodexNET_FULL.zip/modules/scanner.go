package modules

import (
	"fmt"
	"net"
	"strings"
	"time"
)

func Scan(ip, ports string) {
	ps := strings.Split(ports, "-")
	start, end := 1, 1024
	fmt.Sscan(ps[0], &start)
	fmt.Sscan(ps[1], &end)

	for p := start; p <= end; p++ {
		addr := fmt.Sprintf("%s:%d", ip, p)
		conn, err := net.DialTimeout("tcp", addr, 500*time.Millisecond)
		if err == nil {
			fmt.Println("[OPEN]", p)
			conn.Close()
		}
	}
}
