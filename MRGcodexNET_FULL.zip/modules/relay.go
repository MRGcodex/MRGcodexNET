package modules

import (
	"fmt"
	"io"
	"net"
)

func Relay(localPort, remote string) {
	ln, _ := net.Listen("tcp", ":"+localPort)
	fmt.Println("[+] Relay listening on", localPort)

	for {
		lc, _ := ln.Accept()
		go func() {
			rc, _ := net.Dial("tcp", remote)
			go io.Copy(rc, lc)
			io.Copy(lc, rc)
		}()
	}
}
