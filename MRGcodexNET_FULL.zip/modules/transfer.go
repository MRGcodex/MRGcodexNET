package modules

import (
	"fmt"
	"io"
	"net"
	"os"

	"mrgcodexnet/crypto"
)

func SendFile(file, target, password string) {
	key := crypto.KeyFromPassword(password)
	conn, _ := net.Dial("tcp", target)
	defer conn.Close()

	f, _ := os.Open(file)
	defer f.Close()

	buf := make([]byte, 4096)
	for {
		n, err := f.Read(buf)
		if n > 0 {
			enc, _ := crypto.Encrypt(buf[:n], key)
			conn.Write(enc)
		}
		if err == io.EOF {
			break
		}
	}
	fmt.Println("[+] File sent")
}
